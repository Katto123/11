# zEditor
### *a light weight rich text editor*

***

一款超轻量级富文本编辑器，不需要任何依赖（样式、脚本、图标等），原生JS和H5实现，方便您进行学习

该项目特点：

- 简洁美观易读
- 1行js核心代码实现所有功能
- 无依赖

预览图

![zEditor](img/zEditor.png)

[demo](http://tuobaye.com/demo/zEditor/index)